package complexnumber;

public class ComplexNumber {
	private double fReal;
	private double fImaginary;

	public ComplexNumber(double re, double im) {
		fReal = re;
		fImaginary = im;
	}

	public double getReal() {
		return fReal;
	}

	public double getImaginary() {
		return fImaginary;
	}

	public ComplexNumber add(ComplexNumber c) {
		return new ComplexNumber(getReal() + c.getReal(), getImaginary() + c.getImaginary());
	}

	public ComplexNumber multiply(ComplexNumber c) {
		double re = getReal() * c.getReal() - getImaginary() * c.getImaginary();
		double im = getImaginary() * c.getReal() + getReal() * c.getImaginary();
		return new ComplexNumber(re, im);
	}

	public boolean equals(Object anObject) {
		if (anObject instanceof ComplexNumber) {
			ComplexNumber c = (ComplexNumber) anObject;
			return ((c.getReal() == getReal()) && (c.getImaginary() == getImaginary()));
		} else
			return false;
	}
}
